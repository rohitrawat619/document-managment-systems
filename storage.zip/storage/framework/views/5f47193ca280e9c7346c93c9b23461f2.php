<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="page-content">
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
            <div class="breadcrumb-title pe-3">Document Type</div>
            <div class="ps-3">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0 p-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><i class="bx bx-home-alt"></i></a>
                        </li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.document.letter.index')); ?>">Letter</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Edit</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!--end breadcrumb-->
        <div class="row">
            <div class="col-xl-12 mx-auto">
                <div class="card">
                    <div class="card-body p-4">
                        <form action="<?php echo e(route('admin.document.letter.edit', $letter->id)); ?>" method="post" class="row g-3" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if(Auth::user()->is_admin==1): ?>
                                <div class="col-md-6">
                                    <label for="division" class="form-label">Division <span class="text-danger">*</span></label>
                                    <select class="form-control" name="division">
                                        <option value="">--Select--</option>
                                 
                                           
                                              <option value="<?php echo e($divisions->id); ?>"  selected><?php echo e($divisions->name); ?></option>
                            
                                    </select>
                                    <?php if($errors->has('division')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('division')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <div class="col-md-6">
                                <label for="computer_no" class="form-label">Computer No.(E/P) <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="computer_no" name="computer_no" value="<?php echo e($letter->computer_no); ?>" placeholder="computer no">
                                <?php if($errors->has('computer_no')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('computer_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="file_no" class="form-label">File No. <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="file_no" name="file_no" value="<?php echo e($letter->file_no); ?>" placeholder="L-1222/1/2024-IA-I-(R)">
                                <?php if($errors->has('file_no')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('file_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="date_of_issue" class="form-label">Date of Issue <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="date_of_issue" name="date_of_issue" value="<?php echo e($letter->date_of_issue); ?>" placeholder="date of issue">
                                <?php if($errors->has('date_of_issue')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('date_of_issue')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="subject" class="form-label">Subject <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="subject" name="subject" value="<?php echo e($letter->subject); ?>" placeholder="">
                                <?php if($errors->has('subject')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('subject')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="issuer_name" class="form-label">Issuer Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="issuer_name" name="issuer_name" value="<?php echo e($letter->issuer_name); ?>" placeholder="">
                                <?php if($errors->has('issuer_name')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('issuer_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="issuer_designation" class="form-label">Issuer Designation <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="issuer_designation" name="issuer_designation" value="<?php echo e($letter->issuer_designation); ?>" placeholder="">
                                <?php if($errors->has('issuer_designation')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('issuer_designation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="date_of_upload" class="form-label">Date of Upload <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="date_of_upload" name="date_of_upload" value="<?php echo e(date('Y-m-d')); ?>" placeholder="date of issue" readonly>
                                <?php if($errors->has('date_of_upload')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('date_of_upload')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="upload_file" class="form-label">Upload File <small>(In PDF Format, Max: 20MB)</small> <span class="text-danger">*</span></label>

                                <div class="field_wrapper">
                                    <?php if(count($letterUpload) == 0): ?>
                                        <div class="file-input-group d-flex align-items-center">
                                            <input type="file" class="form-control" name="upload_file[]">
                                            <a href="javascript:void(0);" class="remove_button ms-2" style="display:none;">
                                                <img src="<?php echo e(url('assets/images/link-images/remove-icon.png')); ?>" />
                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $letterUpload; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $omu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="file-input-group d-flex align-items-center" id="file-<?php echo e($key); ?>" >
                                            <input type="file" class="form-control" name="upload_file[]" disabled>
                                            <input type="hidden" name="existing_files[]" value="<?php echo e($omu['file_path']); ?>">
                                            <span class="ms-2"><?php echo e($omu['file_name']); ?></span>
                                            <!-- Include data-id attribute here -->
                                            <button type="button" class="view_pdf ms-2 my-2 btn btn-primary" data-file="<?php echo e(Storage::url($omu['file_path'])); ?>">View PDF</button>
                                            <a href="javascript:void(0);" class="remove_button ms-2 my-2" title="Remove file" data-id="<?php echo e($omu['id']); ?>">
                                                <img src="<?php echo e(url('assets/images/link-images/remove-icon.png')); ?>" />
                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>

                                <!-- Add button -->
                                <a href="javascript:void(0);" class="add_button ms-2" title="Add field">
                                    <img src="<?php echo e(url('assets/images/link-images/add-icon.png')); ?>" />
                                </a>

                                <?php if($errors->has('upload_file')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('upload_file')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-6">
                                <label for="file_type" class="form-label">File Type <span class="text-danger">*</span></label>
                                <select class="form-control" name="file_type">
                                    <option value="0" <?php if($letter->file_type == 0): ?> selected <?php endif; ?>>Confidential</option>
                                    <option value="1" <?php if($letter->file_type == 1): ?> selected <?php endif; ?>>Non-Confidential</option>
                                </select>

                                <?php if($errors->has('file_type')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('file_type')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div id="pdfViewer" style="margin-top: 20px;">
                            <iframe id="pdfIframe" width="100%" height="600px" style="display:none;" frameborder="0"></iframe>
                            </div>

                            </div>
                            <div class="col-md-12">
                                <div class="d-md-flex d-grid align-items-center gap-3">
                                    <button type="submit" class="btn btn-primary px-4">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <!--end row-->
    </div>
</div>



<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    var maxField = 5; 
    var addButton = $('.add_button'); 
    var wrapper = $('.field_wrapper'); 
    <?php $removeIconUrl = url('assets/images/link-images/remove-icon.png'); ?>
    var removeIconUrl = '<?php echo e($removeIconUrl); ?>';

    var fieldHTML = '<div class="file-input-group d-flex align-items-center">' +
                    '<input type="file" class="form-control" name="upload_file[]">' +
                    '<button type="button" class="view_pdf ms-2 my-2 btn btn-primary" style="display:none;">View PDF</button>' + 
                    '<a href="javascript:void(0);" class="remove_button ms-2 my-2">' +
                    '<img src="' + removeIconUrl + '" alt="remove" />' +
                    '</a>'  +
                    '</div>';

    var x = wrapper.children('div').length; 

    $(addButton).click(function() {
        if (x < maxField) { 
            x++; 
            $(wrapper).append(fieldHTML); 

            $(wrapper).find('input[type="file"]').last().change(function(e) {
                var file = e.target.files[0];
                var viewButton = $(this).siblings('.view_pdf');  
                if (file && file.type === 'application/pdf') {
                    viewButton.show();
                    viewButton.click(function() {
                        var fileURL = URL.createObjectURL(file);
                        $('#pdfIframe').attr('src', fileURL).show(); 
                    });
                }
            });
        } else {
            alert('A maximum of ' + maxField + ' fields are allowed to be added.');
        }
    });

    $(wrapper).on('click', '.remove_button', function(e) {
    e.preventDefault(); 
    
    var filePath = $(this).siblings('input[type="hidden"]').val();
    var fileId = $(this).data('id');

    if (filePath) {
        if (confirm('Are you sure you want to delete this file?')) {
            var $currentElement = $(this).closest('.file-input-group'); 
            $.ajax({
                url: "<?php echo e(route('admin.document.letter.delete_file')); ?>", 
                type: 'DELETE',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    file_path: filePath,
                    file_id: fileId,
                    delete_from_storage: true
                },
                success: function(response) {
                    alert('File deleted successfully!');
                    $currentElement.find('input[type="hidden"]').val(''); 
                    $currentElement.remove(); 
                    location.reload();

                    var currentFileCount = $('.file-input-group').length;

                    
                    if (currentFileCount >= 5) {
                        alert('You cannot add more than 5 files.');
                    }
                },
                error: function() {
                    alert('An error occurred while deleting the file.');
                }
            });
        }
    } else {
        $(this).closest('.file-input-group').remove();
        x--;
    }
});



    $(document).on('click', '.view_pdf', function() {
        var fileURL = $(this).data('file'); 
        $('#pdfIframe').attr('src', fileURL).show();
    });
});
</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>














<?php echo $__env->make('layouts.backend.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/homebrew/var/www/dms/resources/views/backend/document_types/letter/edit.blade.php ENDPATH**/ ?>